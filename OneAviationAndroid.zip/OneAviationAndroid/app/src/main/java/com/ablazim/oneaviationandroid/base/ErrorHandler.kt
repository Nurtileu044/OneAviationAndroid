package com.ablazim.oneaviationandroid.base

import android.content.Context
import kotlinx.coroutines.CancellationException

class ErrorHandler(private val context: Context) {

    fun handle(e: Throwable) {
        if (e is CancellationException) return
        /*if (BuildConfig.DEBUG && e is IOException) {
//            context.longToast(e.message ?: "")
        } else {
//            context.toast("")
        }*/
    }
}