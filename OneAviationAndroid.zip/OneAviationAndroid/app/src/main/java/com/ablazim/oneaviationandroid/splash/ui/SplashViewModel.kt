package com.ablazim.oneaviationandroid.splash.ui

class SplashViewModel(
    baseViewModelDependency: BaseViewModelDependency
) : BaseViewModel<EmptyState, SplashAction>() {

}

sealed class SplashAction : Action {

}