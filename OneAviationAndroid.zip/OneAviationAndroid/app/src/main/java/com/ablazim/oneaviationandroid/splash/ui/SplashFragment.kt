package com.ablazim.oneaviationandroid.splash.ui

import androidx.fragment.app.Fragment
import com.ablazim.oneaviationandroid.R

class SplashFragment : Fragment(R.layout.fragment_splash) {

    private val viewModel: SplashViewModel by viewModel()

}